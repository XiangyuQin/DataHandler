# -*- coding:utf-8 -*-
article='''
<table cellspacing="0" cellpadding="0">
 <tbody>
  <tr>
   <td class="t_f" id="postmessage_2268688"> <strong>　　牛郎选择去偷了织女的衣服，而不是跑过去殷勤地对织女说你好。七仙女挡住了董永的去路，而不是说：对不起，打扰一下。伟大的爱情，总得先从耍流氓开始。事情只有开始的时候就顺利，结果才会好。一个让人意外的开场，能创造一段美好的<a href="http://www.puahome.com/" target="_blank">恋爱</a>关系。</strong><br /> <br /> 
    <div align="center"> 
     <ignore_js_op> 
      <img id="aimg_129912" aid="129912" src="static/image/common/none.gif" zoomfile="data/attachment/forum/201602/04/140837sch0io3b03t4ct60.jpg" file="data/attachment/forum/201602/04/140837sch0io3b03t4ct60.jpg" class="zoom" onclick="zoom(this, this.src, 0, 0, 0)" width="210" inpost="1" onmouseover="showMenu({'ctrlid':this.id,'pos':'12'})" /> 
      <div class="tip tip_4 aimg_tip" id="aimg_129912_menu" style="position: absolute; display: none" disautofocus="true"> 
       <div class="xs0"> 
        <p><strong>2909747.jpg</strong> <em class="xg1">(32.19 KB, 下载次数: 4)</em></p> 
        <p> <a href="http://www.puahome.com/bbs/forum.php?mod=attachment&amp;aid=MTI5OTEyfGVhZjU1YjQ0fDE0NTUzMzYxMTF8MHw5MTA1OQ%3D%3D&amp;nothumb=yes" target="_blank">下载附件</a> </p> 
        <p class="xg1 y">2016-2-4 14:08 上传</p> 
       </div> 
       <div class="tip_horn"></div> 
      </div> 
     </ignore_js_op> 
    </div><br /> 　　你会发现，与众不同人做什么都不太一样，包括<a href="http://www.puahome.com/bbs/" target="_blank">把妹</a>。<br /> <br /> 　　在社交当中，这些与众不同的人会跳过人的常规思维，做出一些新的状况出来，而不是循规蹈矩地去和妹子说你好。<br /> <br /> 　　我们都知道人在开始接触的时候会有一个互相去说客套话的阶段。<br /> <br /> 　　你好，你好。吃了嘛?吃了。<br /> <br /> 　　很高兴认识你，我也很高兴认识你。<br /> <br /> 　　这些看起来完全是废话的玩意，之所以能在人类社会行为中延续这么久，是因为它能帮助人在刚认识的时候起到一个缓冲的作用，不至于太尴尬。<br /> <br /> 　　而且两个陌生人刚接触的时候，谁都不知道对方的性格如何，万一对方是个混球呢?<br /> <br /> 　　用一些客套话去试探对方的反应，看看对方是否会做出正确而有礼貌的回应，如果回应是正常的，那么这个人就是安全的。<br /> <br /> 　　这个行为和狗互相见面会闻对方的屁股是一样的，判断对方的安全性。<br /> <br /> 　　当这些东西在人类社会中沉淀的足够久时，就会形成心理学上说的人类的“机械化反应”，就是你每天都会听到的那些废话。<br /> <br /> 　　我想说的是这些废话对普通社交是有好处的，但是对于把妹，却完全无鸟用。<br /> <br /> 　　把妹是一个从一开始就要求抓住女人注意力的行为，然后通过<a href="http://www.puahome.com/wiki/doc-view-81.html" target="_blank">吸引</a>去触发女人的投资。<br /> <br /> 　　但是显然人类的意识不会被那些天天出现在我们生活里循规蹈矩的事物所吸引。<br /> <br /> 　　只有新奇的东西会让我们觉得有趣，抓住我们的注意力，这也就是为什么各类突发事件报道、社会新闻会每天占据我们大量阅读时间的原因。<br /> <br /> 　　人类喜欢新的东西，没见过的东西，虽然那可能是危险的，但是却有可能是某个改变你生活的契机。<br /> <br /> 　　我们的潜意识比主观意识更懂得这一点，所以我们从来都是乐此不疲开发和认识新事物。<br /> <br /> 　　那么既然要把妹，我们就需要一些与众不同的新路子。<br /> <br /> 　　Play恋爱的教学更懂得这一点，看似短短的一个<a href="http://www.puahome.com/wiki/doc-view-161.html" target="_blank">开场白</a>，就要让妹子从一开始就知道，我们不是她每天看到的那些嘴上说你好，实际精虫上脑只想操她的屌丝。<br /> <br /> 　　先来看用普通开场白是什么效果<br /> 　　▼<br /> <br /> 
    <div align="center"></div><br /> <br /> 
    <div align="center"></div><br /> <br /> 　　▲反应可谓是平坦如飞机场<br /> <br /> 　　上面这是普通人的做法，试图通过正常的接触，然后慢慢靠近女人，但是你有极大的几率被发朋友卡，<a href="http://www.puahome.com/wiki/doc-view-78.html" target="_blank">好人卡</a>。<br /> <br /> 　　因为你的行为太普通了，你从一开始就没有引发她的注意和情绪，所以她很快就会觉得无聊，然后不再回复信息了。<br /> <br /> 　　我们需要打破她的机械化反应，那么要打破她的机械化反应，就绝对不可以做循规蹈矩的动作。<br /> <br /> 　　要做奇怪的说话开场，让她先楞一下，但是也不可以惹怒她，只是一个奇怪但是好像更好玩的说话，捕捉他的注意力。<br /> <br /> 　　说一些需要她真正要动脑子才能回答的话，而不是让她想都不用想的就知道回答你的话。<br /> <br /> 　　再来看用奇特开场白开场<br /> 　　▼<br /> <br /> 
    <div align="center"></div><br /> <br /> 
    <div align="center"></div><br /> <br /> 
    <div align="center"></div><br /> <br /> 
    <div align="center"></div><br /> <br /> 　　▲反馈丰满而有延展性<br /> <br /> 　　那么你可以看到，她完全没有做出“机械化反应”，而是认真思考之后回答我的问题，这更接近她的真实情绪，play恋爱是玩弄感觉的人，我只有在看到对方真正的情绪之后才能决定我接下来要用什么样的招数。<br /> <br /> 　　那么我做了一个不错的开场白之后，对方的真实反应能帮助我们创造出更多更有趣的话题，继续用奇怪的话题，让她去动脑子，让她感觉好玩。<br /> <br /> 　　所以我很快就创造出了她奇妙的情绪体验和互动，你可以看的出她很开心，那么这就是你能开启一段美好关系的保障。<br /> <br /> 　　那窍门在什么地方呢?<br /> <br /> 　　窍门就是绝对不用循规蹈矩的话做开场，用奇怪的话打破她的机械化反应。<br /> <br /> 　　我这给大家准备了几个<a href="http://www.puahome.com/wiki/doc-view-133.html" target="_blank">惯例</a>，你们待会可以试试。<br /> <br /> 　　➤正确示范<br /> <br /> 　　你觉得女人会在什么时候更容易被男人吸引?<br /> <br /> 　　你觉得化妆的男人怎么样?<br /> <br /> 　　你有没有在失恋之后哭醒过?<br /> <br /> 　　在你决定说出奇怪的话时，一定不要为了奇怪而过分，说出惹怒对方的话。<br /> <br /> 　　意外但是有趣，而不是意外的吓人。<br /> <br /> 　　➤错误示范<br /> <br /> 　　嗨，你觉得你骚么?<br /> <br /> 　　你和几个男人上过床?<br /> <br /> 　　你想和我做爱么?<br /> <br /> 　　以及这种只能由鸡哥运用的开场：<br /> <br /> 
    <div align="center"></div><br /> <br /> 　　以及这个谜样的：<br /> <br /> 
    <div align="center"></div><br /> <br /> 　　如果你像上面这样开场，我只能祝你平安了。<br /> <br /> &nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;-------------------------------------------------------<br /> <br /> &nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;关注坏男孩 - 掌握<a href="http://www.puahome.com/" target="_blank">追女生</a>的技巧。<br /> <br /> &nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;手机用户点这里：<br /> &nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;<a href="http://m.puahome.com/topic/rookiewap/1.html" target="_blank">http://m.puahome.com/topic/rookiewap/1.html</a><br /> <br /> &nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;电脑用户点这里：<br /> &nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;<a href="http://www.puahome.com/welcome" target="_blank">http://www.puahome.com/welcome</a><br /> <br /> &nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;-------------------------------------------------------<br /> <br /> &nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;还在为找不到<a href="http://nvyou.puahome.com/" target="_blank">女朋友</a>被亲戚嘲笑吗，还总是被女神干嘛呵呵去洗澡吗，还因为你是个<a href="http://www.puahome.com/wiki/doc-view-78.html" target="_blank">好人</a>可是不能在一起而苦恼吗？<br /> <br /> &nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;晚7点-凌晨1点，<a href="http://www.puahome.com/wiki/" target="_blank">约会学</a>课程免费放送，各路<a href="http://www.puahome.com/bbs" target="_blank">把妹达人</a>等你来。点击链接在线收听：<a href="http://t.cn/RyZi9I2" target="_blank">http://t.cn/RyZi9I2</a><br /> <br /> <br /> <br /> <br /> <br /> </td>
  </tr>
 </tbody>
</table>
'''